const http = require("http")
const fs =  require("fs");
const url = require("url")
let userObj;

fs.readFile('input.txt','utf-8',(err,data) => {
    if(err){
        console.log("Error");
    }
    userObj = JSON.parse(data)
    // console.log(userObj)
})

let writeFile = (userObj) => {
    fs.writeFile('input.txt', JSON.stringify(userObj), (err) => {
        if(err) {
            console.log("error writing input.txt");
        }
        console.log("File has been updated successfully");
    })
}
// writeFile({"amo":1234567891,"abc":0987654,"xyz":34567890})
const server=http.createServer((req,res)=>{
    res.writeHead(200,{ 'Content-Type' : "application/json"})
    var parseUrl = url.parse(req.url, true).pathname;
    var params = url.parse(req.url, true).query;
    // console.log(parseUrl)
    // console.log(params)

    if(parseUrl == '/directory/add'){
        userObj.push({ [params.name] : params.number})
        writeFile(userObj)
        res.write(JSON.stringify(userObj))
        res.end()
    }else if(parseUrl == '/directory/delete'){
        userObj = userObj.filter(
        users => Object.keys(users) != params.name)
        writeFile(userObj)
        res.write(JSON.stringify(userObj))
        res.end()
    }else if(parseUrl == '/directory/show'){
        res.write(JSON.stringify(userObj))
        res.end()
    }else if(parseUrl == '/directory/update'){
        userObj.map(ele=>{
            if([params.name] in ele){
                ele[params.name] =(params.number)
            }    

        })
            userObj.push({ [params.name] :(params.number) })
            writeFile(userObj)
            res.write(JSON.stringify(userObj))
            res.end()   
    }
    
})

server.listen(8000, (err) => {
    if(err){
        console.log("Problem to listning port 8000")
    }
    console.log("server listning at port 8000");
})