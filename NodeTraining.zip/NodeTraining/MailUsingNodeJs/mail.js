const nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport
    ({
        host: 'smtp-mail.outlook.com',
        port: 587,
        auth: {
            user: 'shakshi.thakur@scikey.ai',
            pass: 'gvzjdftpptpgsgqc'
        }
    });
// send mail with defined transport object  
transporter.sendMail
    ({
        from: 'shakshi.thakur@scikey.ai', // sender address   
        to: "priyank.khanpara@scikey.ai",
        subject: "Assignment-5", //Subject line    
        text: "NodeMailer",  // plain text body
        attachments:[{
            filename:'data.xlsx',path:'./data.xlsx'
        }]
        
    });
console.log("Message sent");