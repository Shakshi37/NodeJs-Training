const http = require('http')
const fs = require('fs')
const url = require('url')
const server = http.createServer((req, res) => {

    //Search Single User Based on Id
    // console.log(url.parse(req.url,true).query.id)
    let id = url.parse(req.url, true).query.id
    if (id) {
        var file = fs.readFileSync("task.json", 'utf8')
        file = JSON.parse(file)
        var data;
        file.forEach((obj, index) => {
            if (obj.id === parseInt(id)) {
                data = obj
            }
        });

        res.end(JSON.stringify(data))
    }

    //Total Amount and GET METHOD
    if (req.method === "GET") {
        fs.readFile("task.json", 'utf8', (err, result) => {
            if (err) {
                res.end("Error")
            }
            res.write(result)
            let totalAmount = 0;
            file = JSON.parse(result)
            file.forEach(ele => {
                if (ele.operation == "credit") {
                    totalAmount += ele.ExpenditureAmount
                } else if (ele.operation == "debit") {
                    totalAmount -= ele.ExpenditureAmount
                }
            })
            console.log(totalAmount)
            res.end("Available Balance : " + totalAmount.toString())
        })

    }
    //POST /CREATE DATA
    if (req.method === "POST") {
        var body;
        // console.log(req)
        // res.end("Recieved")
        req.on("data", (data) => {
            body += data;
        })
        req.on("end", () => {
            // console.log(JSON.parse(body)) --return string type data
            body = JSON.parse(body.replace("undefined", ""))
            var file = fs.readFileSync("task.json", 'utf8')
            // console.log(body)
            // console.log(file)  ---data recieved in string format so we have to convert it into json 
            // console.log(JSON.parse(file))
            file = JSON.parse(file)
            var maxId = 0
            file.forEach(obj => {
                if (obj.id > maxId) maxId = obj.id
            });
            // console.log(maxId)
            body.id = maxId + 1
            console.log(body)
            // res.end("Recieved")
            file.push(body)
            // console.log(file)
            fs.writeFileSync("task.json", JSON.stringify(file))
            res.end(JSON.stringify(body))
        })

    }

    //PUT METHOD /UPDATE
    if (req.method === "PUT") {
        var bodyupdate;
        req.on("data", (data) => {
            bodyupdate += data;
        })
        req.on("end", () => {
            bodyupdate = JSON.parse(bodyupdate.replace("undefined", ""))
            var file = fs.readFileSync("task.json", 'utf8')
            file = JSON.parse(file)
            var id = bodyupdate.id
            file.forEach((obj, index) => {
                if (obj.id === id) {
                    file[index] = bodyupdate
                }
            });
            // console.log(bodyupdate)
            // console.log(file)
            fs.writeFileSync("task.json", JSON.stringify(file))
            res.end(JSON.stringify(bodyupdate))
        })
    }


    //DELETE 
    if (req.method === "DELETE") {
        var bodyupdate;
        req.on("data", (data) => {
            bodyupdate += data;
        })
        req.on("end", () => {
            bodyupdate = JSON.parse(bodyupdate.replace("undefined", ""))
            var file = fs.readFileSync("task.json", 'utf8')
            file = JSON.parse(file)
            var id = bodyupdate.id
            file.forEach((obj, index) => {
                if (obj.id === id) {
                    // file[index]=bodyupdate
                    // delete file[index]  -------------it return empty itrm 
                    file.splice(index, index + 1);
                }
            });
            // console.log(bodyupdate)
            console.log(file)
            fs.writeFileSync("task.json", JSON.stringify(file))
            res.end(JSON.stringify("Deleted"))
        })

    }
})
server.listen(5000, () => {
    console.log("Server Running at port 5000")
})