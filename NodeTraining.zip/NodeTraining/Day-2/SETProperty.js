const letters = new Set();
//------------------------------------set in js---------------------------------------
// Add Values to the Set
letters.add("a");
letters.add("b");
letters.add("c");
arrfinal=[]
letters.forEach(element => {

    arrfinal.push(element)
});
console.log(arrfinal)