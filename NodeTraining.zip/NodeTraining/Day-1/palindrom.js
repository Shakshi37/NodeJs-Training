function palindrome(str) {
    var re = /[\W_]/g;
    var lowRegStr = str.toLowerCase().replace(re, '');
    var reverseStr = lowRegStr.split('').reverse().join(''); 
    return reverseStr === lowRegStr;
    // console.log(lowRegStr.split('').reverse().join(''))
  }
// palindrome("A man, a plan, a canal. Panama");

let check=palindrome("A man, a plan, a canal. Panama")
if(check==true){
    console.log("Its a palindrome")
}else{
    console.log("Its not a palindrome")
}


