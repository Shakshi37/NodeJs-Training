const x=[
    {
        Emp_code: "SCIKEY01",
        Name: "Hardik",
        Designation: "PM",
        Business_unit: "Scikey",
        Branch: "Surat",
        DOB: "28-09-1997",
        Department: "PMS",
        DOJ: "22-02-2002",
        Email: "hardik@gmail.com",
        Mob_no: "9977886601",
        Gender: "MALE",
        Experience: 3
    },
    {
        Emp_code: "SCIKEY02",
        Name: "Vidhi",
        Designation: "AD",
        Business_unit: "Scikey",
        Branch: "Surat",
        DOB: "05-05-2000",
        Department: "AMS",
        DOJ: "04-09-2002",
        Email: "vidhi@gmail.com",
        Mob_no: "8237767340",
        Gender: "FEMALE",
        Experience: 2,
        salary: 30000
    },
    {
        Emp_code: "SCIKEY04",
        Name: "Pratik",
        Designation: "DEV",
        Business_unit: "Scikey",
        Branch: "Mumbai",
        DOB: "30-10-1987",
        Department: "GMS",
        DOJ: "10-02-2006",
        Email: "pratik.khan@gmail.com",
        Mob_no: "999978801",
        Gender: "MALE",
        Experience: 10,
        salary: 80000
    },
    {
        Emp_code: "SCIKEY05",
        Name: "Komal",
        Designation: "SDEV",
        Business_unit: "Scikey",
        Branch: "Surat",
        DOB: "28-05-1990",
        Department: "AMS",
        DOJ: "15-03-2001",
        Email: "komal@gmail.com",
        Mob_no: "997788000",
        Gender: "FEMALE",
        Experience: 1
    },
    {
        Emp_code: "SCIKEY06",
        Name: "Raj",
        Designation: "PM",
        Business_unit: "Scikey",
        Branch: "Mumbai",
        DOB: "28-09-1977",
        Department: "PMS",
        DOJ: "10-02-2000",
        Email: "raj@gmail.com",
        Mob_no: "9977885555",
        Gender: "MALE",
        Experience: 3,
        salary: 38000
    },
    {
        Emp_code: "SCIKEY07",
        Name: "Tisha",
        Designation: "PM",
        Business_unit: "Scikey",
        Branch: "Surat",
        DOB: "22-03-1997",
        Department: "PMS",
        DOJ: "22-02-2002",
        Email: "tisha@gmail.com",
        Mob_no: "2222286601",
        Gender: "FEMALE",
        Experience: 3,
        salary: 50000
    }
]


    
x.sort((a,b)=>{
    if(a.Emp_code.toString()>b.Emp_code.toString())
    return -1
    // if(a.Name.toString()>b.Name.toString())
    // return -1
    // if(a.Designation.toString()>b.Designation.toString())
    // return -1
    // if(a.Branch.toString()>b.Branch.toString())
    // return -1
    // var dateA = new Date(a.DOB), dateB = new Date(b.DOB);
    // if (dateB < dateA) {
    //     return -1;
    // }
    // return (b.Experience - a.Experience)
    // if(b.salary - a.salary){
    // return -1
    // }
    
})


console.log(x)


