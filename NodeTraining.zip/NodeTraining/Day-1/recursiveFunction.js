// //declaration of function power
// function pow(a,b) {
//     //writing if condition and checking if it has broken into simplest task already
//     if (b == 1) {
//     //returning the value which needs to be reiterated
//     return a;
//     } else {
//     return a * pow(a, b - 1);
//     }
//     }
//     //recursively calling the function pow by passing two values to process
//     console.log(pow(2, 3))

// var greet = function () {
//     console.log("Hello World");
// };

// greet();

// 	(function () {
// 		console.log("Hello World");
// 	})();

// function Person(first, last, age, eye) {
//     this.firstName = first;
//     this.lastName = last;
//     this.age = age;
//     this.eyeColor = eye;
// }

// const myFather = new Person("John", "Doe", 50, "blue");
// const myMother = new Person("Sally", "Rally", 48, "green");
// console.log("My father age is " + myFather.age + " and  My mother age is " + myMother.age)
const object1 = {
    a: 1,
    b: 2,
    c: 3
  };
  
console.log(Object.getOwnPropertyNames(object1));
  