const Logger = require("./Logger")
const logger = new Logger()
const blogger=new Logger()
const clogger=new Logger()
const dlogger=new Logger()
logger.on("logMessage", arg => {
    console.log("Listened value => ", arg)
})
blogger.on("logMessage", arg => {
    console.warn("Listened value => ", arg)
})
clogger.on("logMessage", arg => {
    console.error("Listened value => ", arg)
})
dlogger.on("logMessage", arg => {
    console.info("Listened value => ", arg)
})

logger.logIt("logMessage", "log")
blogger.logIt("logMessage", "warn")
clogger.logIt("logMessage", "Error")
dlogger.logIt("logMessage", "info")
