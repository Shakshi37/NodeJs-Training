

const ziplocal=require('zip-local')
ziplocal.sync.zip("Shakshi_Assignment-5").compress().save("Shakshi_Assignment-5.zip")