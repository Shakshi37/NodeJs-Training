var arr=[10, 20, 15, 2, 23, 90, 67,100,3]


const x= arr.sort(function(a, b){return a - b});
console.log(x)