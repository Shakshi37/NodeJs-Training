let arr = [ 1, 5, 7, -1, 5 ];
let sum=6
for(let i=0;i<arr.length;i++){
    // console.log(arr[i])
    for(let j=i+1 ;j<arr.length;j++){
        // console.log(arr[j])
        if(arr[i]+arr[j]==sum){
            console.log(arr[i],arr[j])
        }
    }
}
