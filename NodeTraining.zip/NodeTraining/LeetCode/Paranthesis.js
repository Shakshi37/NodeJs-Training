var s="(){}["
const stack=[]
// for(i=0;i<a.length;i++){
//     // console.log(a[i])
//     if(a[i]=='[' || a[i]=='(' || a[i]=='{'){
//         stack.push(a[i])
//     }else if(a[i]==']' || a[i]==')' || a[i]=='}'){
//         stack.pop(a[i])
//     }

// }
// if(stack.length==0){
//     console.log("Valid")
// }else{
//     console.log("Invalid")
// }

  
  for (let i = 0; i < s.length; i += 1) {
    const top = stack[stack.length - 1];
    if (s[i] === '(' || s[i] === '{' || s[i] === '[') {
      stack.push(s[i]);
    } else if (s[i] === ')' && top === '(' && stack.length !== 0) {
      stack.pop();
    } else if (s[i] === ']' && top === '[' && stack.length !== 0) {
      stack.pop();
    } else if (s[i] === '}' && top === '{' && stack.length !== 0) {
      stack.pop();
    } 
    // else {
    //   return false;
    // }
  }
  
//   return stack.length === 0;
if(stack.length==0){
    console.log("Valid")
}else{
    console.log("Invalid")
}

