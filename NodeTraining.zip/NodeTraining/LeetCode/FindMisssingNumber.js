var arr=[1, 2, 4, 6, 3, 7, 8]
let N=8
arr_new=[]
for(let i=1;i<=N;i++){
    // console.log(i)
    arr_new.push(i)

}
// console.log(arr_new)

arr_new.map(ele=>{
    // console.log(ele)
    // console.log(arr.includes(ele));
    if(arr.includes(ele)==false){
        console.log(ele)
    }
})