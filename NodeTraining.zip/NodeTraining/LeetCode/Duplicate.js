array=[0,0,1,1,1,2,2,3,3,4]

s=[]
let ans

array.forEach(element => {
    if(!s.includes(element)){
        s.push(element)
    }   
});

// console.log(s)
// console.log(s.length)
console.log(s.length,",", s);
