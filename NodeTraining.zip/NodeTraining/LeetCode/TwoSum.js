// // nums=[2,7,11,15]
// // target=9

// var twoSum = function (nums, target) {
//     let sum = 0
//     let index_arr=[]
//     for (let i = 0; i <
//         nums.length; i++) {
//         const diff = target - nums[i];
//         if (sum != target) {
//             sum += nums[i]
//             console.log(nums[i])
//             let index=nums.indexOf(nums[i])
//             index_arr.push(index)
            
//         }

//         // console.log(sum)

//     }
//     console.log (index_arr)


// };

// twoSum([3,3], 6)
const twoSum=function (nums, target) {
    for(let i = 0;  i < nums.length; i++) {
        for (let j = 0; j < nums.length; j++) {
            // console.log(nums[j])
            if(j == i) continue;
            if((nums[i] + nums[j]) == target) {
                
                // console.log ([i, j]);
                return [i,j]

                
            }
            
        }
    }
}
twoSum([3,2,4], 6)