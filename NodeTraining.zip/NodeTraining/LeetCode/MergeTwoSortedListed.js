// Input: list1 = [1,2,4], list2 = [1,3,4]
// Output: [1,1,2,3,4,4]

// let list1=[1,3,4], list2 = [1,1,2]
// const con = list1.concat(list2).sort();
// console.log(con)
