var arr=[10, 20, 15, 2, 23, 90, 67,100,3]
const x= arr.sort(function(a, b){return a - b});

const k=3
// console.log(x)
for(i=0;i<x.length;i++){
    // console.log(i)
    if(i==k){
        console.log(x[i])
    }
}