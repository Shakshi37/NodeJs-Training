var arr=[1, 1, 2, 2, 2, 2, 3]
const x=2
// ans=[]
// for(let i=0;i<arr.length;i++){
//     // console.log(arr[i])
//     if(arr[i]==x){
//         ans.push(arr[i])
//     }
// }
// console.log(ans.length)

const result= arr.filter(ele=> ele==x);
console.log(result.length)

