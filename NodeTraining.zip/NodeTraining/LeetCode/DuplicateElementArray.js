var array = [1, 2, 3, 6, 3, 6, 1]
ans=[]
for(let i=0;i<array.length;i++){
    for(let j=i+1;j<array.length;j++){
        if(array[i]==array[j]){
            ans.push(array[i])
        }
    }
}

console.log("Output:" + ans)