
const sampleArray = [-1, 2, -1, 3, 0];
const getNonDuplicatedValues = (arr) => 
    arr.filter((item,index) => {
      arr.splice(index,1)
      const unique = !arr.includes(item)
      arr.splice(index,0,item)
      return unique
  })

console.log(...getNonDuplicatedValues(sampleArray[0]))


