ar1 = [1, 5, 5]
ar2 = [3, 4, 5, 5, 10]
ar3 = [5, 5, 10, 20]
var i=0,j=0,k=0;

while(i<ar1.length && j<ar2.length && k<ar3.length){
    if (ar1[i] == ar2[j] && ar2[j] == ar3[k]){
        console.log(ar1[i])
        i++;
        j++;
        k++;
    }
    else if(ar1[i] < ar2[j]){
        i++;
    }else if(ar2[j] < ar3[k]){
        j++;
    }else{
        k++;
    }
}