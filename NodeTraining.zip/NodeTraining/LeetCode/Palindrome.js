var isPalindrome = function(x) {
    if(x.toString().split('').reverse().join('')==x){
        console.log("It is palindrome")
    }else{
        console.log("It is not palindrome")
    }
    //  let num= x.toString().split('').reverse().join('');
    // console.log(num)
};
isPalindrome(121)