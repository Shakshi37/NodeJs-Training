// var arr=[1, 4, 20, 3, 10, 5]
var arr=[1, 4, 0, 0, 3, 10, 5]
// const a=2,b=4;
const a=1 ,b=4;
let sum=0;
for(let i=0;i<arr.length;i++){
    // console.log(i)
    if(i>=a && i<=b ){
        // console.log(i)
        sum += arr[i]
    }
}
console.log(sum)