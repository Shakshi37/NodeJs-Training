var arr=[10, 20, 15, 2, 23, 90, 67,100,3]

const x= arr.reverse()
console.log(x)