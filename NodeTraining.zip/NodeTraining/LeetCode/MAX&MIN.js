var arr=[10, 20, 15, 2, 23, 90, 67,100,3]
const max= Math.max(...arr)
const min= Math.min(...arr)
console.log(max)
console.log(min)