arr1= [1, 3, 4, 5, 7]
arr2= [2, 3, 5, 6]
var union = [...new Set([...arr1, ...arr2])];
//Using set You can iterate through the elements of a set in insertion order

console.log("Union of array; " + union)

const Intersection= arr1.filter(value=>arr2.includes(value))

console.log("Intersection of array; " + Intersection)