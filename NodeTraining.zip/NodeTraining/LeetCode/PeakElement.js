//PEAK ELEMENT FROM ITS NEIGHBOUR
var arr=[10, 20, 15, 2, 23, 90, 67,100,3]

for(let i=0; i<arr.length;i++){
    // console.log(arr[i])
    if(arr[i]>arr[i-1] && arr[i]>arr[i+1] ){
        console.log(arr[i])
    }
}