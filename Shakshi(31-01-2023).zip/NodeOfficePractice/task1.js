const fs=require ('fs')
const http=require('http')
const url=require('url')
let resultObj;
let port=8000;
let sortUsers = (resultObj,order) => {
    let FinalObj = {};
    resultObj.map(users => {
        let userName = Object.keys(users)[0]
        if(!Object.keys(FinalObj).includes(userName[0])){
            FinalObj[userName[0]] = []
        }
        FinalObj[userName[0]].push({ [userName] : Object.values(users)[0]})
    })

    return (
        order == 'desc' ? 
            Object.keys(FinalObj).sort().reverse().reduce((res,key) => ( res[key] = FinalObj[key], res ), {} )
            :
            Object.keys(FinalObj).sort().reduce((res,key) => ( res[key] = FinalObj[key], res ), {} )
    )
}

let WriteData= (resultObj)=>{
    fs.writeFile("task1.txt",JSON.stringify(resultObj),(err)=>{
        if(err){
            console.log("Error")
        }
        console.log("Sucess!!!!!!!!!!!!!")
    })
}

fs.readFile("task1.txt",'utf8',(err,result)=>{
if(err) {
    console.log("Error in reading File")
}
// console.log(result)
resultObj=JSON.parse(result)
})

http.createServer((req,res)=>{
    var PathAddress=url.parse(req.url, true).pathname
    var QueryAddress=url.parse(req.url, true).query
    if(PathAddress=="/directory/show"){
        res.end(JSON.stringify(resultObj))
    }else if(PathAddress=="/directory/add"){
        resultObj.push({[QueryAddress.name]:QueryAddress.number})
        WriteData(resultObj)
        res.write(JSON.stringify(resultObj))
        res.end()
    }else if(PathAddress == '/directory/delete'){
        resultObj = resultObj .filter( users => Object.keys(users) != QueryAddress.name)
        WriteData(resultObj)
        res.write(JSON.stringify(resultObj))
        res.end()
    }else if(PathAddress == '/directory/update'){
        let newUser = true;

        resultObj.map(users => {
            if([QueryAddress.name] in users){
                users[QueryAddress.name] = Number(QueryAddress.number)
                newUser = false
            }
        })

        newUser && resultObj.push({ [QueryAddress.name] : Number(QueryAddress.number) });
        WriteData(resultObj)
        res.write(JSON.stringify(resultObj))
        res.end()
    }else if(PathAddress == '/directory/sort'){
    res.end(`${JSON.stringify(sortUsers(resultObj,QueryAddress.order))}`)

    }else if(PathAddress == '/directory/search'){
    if(QueryAddress.name == '*'){ res.end(`${JSON.stringify(resultObj)}`) }
    else {
        searchedUser = resultObj.filter((users,index) => {
                return (Object.keys(users)[0].includes(QueryAddress.name) ? users : null);
        })
        res.end(`${searchedUser ? JSON.stringify(searchedUser) : 'Not Found'}`)
    }
}
}).listen(port,()=>{
    console.log(`Server Listning at port ${port}`)
})

