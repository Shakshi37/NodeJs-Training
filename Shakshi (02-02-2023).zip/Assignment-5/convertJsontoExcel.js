
const fs = require('fs')

const xlsx = require('xlsx')
var file = fs.readFileSync("book.json", 'utf8')
file = JSON.parse(file)
var workBook = xlsx.utils.book_new() //create new workbook
var worksheet = xlsx.utils.json_to_sheet(file)
//Convert json key as Header and apend data 
xlsx.utils.book_append_sheet(workBook,worksheet)
//Download the sheet
xlsx.writeFile(workBook,"data.xlsx")



