"use strict";
const nodemailer = require("nodemailer");

// create reusable transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'camryn0@ethereal.email',
        pass: 'xmWtJjukSa3JJjnDk3'
    }
});

// send mail with defined transport object
var mailOptions = {
    from: 'tshakshi302@gmail.com', // sender address
    to: "thakurshakshi22770@gmail.com", // list of receivers
    subject: "Assignment-5", // Subject line
    text: "Mail Through Node Mailer", // plain text body
    attachments:[{
        filename:'data.xlsx',path:'C://Users//Shakshi.Thakur//Desktop//NodeJs//NodeTraining//Assignment-3//03-02-2023//data.xlsx'
    }]
};
transporter.sendMail(mailOptions, function (err, info) {
    if (err) {
        console.log("Error")
    } else {
        console.log("Sucessfully sent".info.response)
    }
})