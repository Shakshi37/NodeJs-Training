const http = require('http')
const fs = require('fs')
const url = require('url')
const server= http.createServer((req,res)=>{
    if (req.method == "GET" && req.url === '/') {
        fs.readFile("book.json", 'utf8', (err, result) => {
            if (err) {
                res.end("Error")
            }
            res.write(result)
            res.end()
        })

    }else if(req.method == "GET" && req.url === '/return'){
        var body;
        req.on("data", (data) => {
            body += data;
        })
        req.on("end", () => {
            body = JSON.parse(body.replace("undefined", ""))
            var file = fs.readFileSync("book.json", 'utf8')
            file = JSON.parse(file)
            var maxId = 0
            file.forEach(obj => {
                if (obj.bookId > maxId) maxId = obj.bookId
            });
            // console.log(maxId)
            // body.bookid = maxId + 1
            console.log(body)
            file.push(body)
            fs.writeFileSync("book.json", JSON.stringify(file))
            res.end(JSON.stringify(file))
        })
    }else if(req.method == "GET" && req.url === '/issue'){
        var file = fs.readFileSync("book.json", 'utf8')
        file = JSON.parse(file)
        var bodyupdate;
        req.on("data", (data) => {
            bodyupdate += data;
        })
        req.on("end", () => {
            bodyupdate = JSON.parse(bodyupdate.replace("undefined", ""))
    
            var id = (bodyupdate.bookId)
            file.forEach((obj, index) => {
                if ((obj.bookId) === id) {
                    // file[index]=bodyupdate
                    // delete file[index]  -------------it return empty itrm 
                    file.splice(index, index + 1);
                }
            });
            // console.log(bodyupdate)
            // console.log(file)
            fs.writeFileSync("book.json", JSON.stringify(file))
            res.end(JSON.stringify("Book Issued Sucessfully"))
        })
    }
})

server.listen(8000,()=>{
    console.log("Server is listing on port 8000")
})